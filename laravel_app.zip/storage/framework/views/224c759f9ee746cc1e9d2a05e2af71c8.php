<!DOCTYPE html>
<html>
<head>
    <title>Laporan Data Balita & Stunting Singaparna</title>
    <style>
        body { font-family: sans-serif; font-size: 10pt; color: #333; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #ddd; padding: 6px; text-align: left; }
        th { background-color: #f2f2f2; text-align: center; font-weight: bold; }
        .header { text-align: center; margin-bottom: 20px; }
        .header h2 { margin: 0; font-size: 14pt; }
        .header h3 { margin: 2px 0; font-size: 12pt; }
        .header p { margin: 2px 0; font-size: 10pt; color: #555; }
        .text-center { text-align: center; }
    </style>
</head>
<body>
    <div class="header">
        <h2>PEMERINTAH KABUPATEN TASIKMALAYA</h2>
        <h3>KANTOR KECAMATAN SINGAPARNA</h3>
        <p>Laporan Data Balita dan Status Penimbangan Stunting</p>
        <hr>
    </div>

    <table>
        <thead>
            <tr>
                <th width="5%">No</th>
                <th width="22%">NIK</th>
                <th width="20%">Nama Balita</th>
                <th width="5%">L/P</th>
                <th width="20%">Nama Orang Tua</th>
                <th width="13%">Posyandu</th>
                <th width="15%">Status Gizi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $balitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $status = $b->penimbanganTerakhir->status_gizi ?? $b->status_gizi ?? 'Belum Ditimbang';
            ?>
            <tr>
                <td class="text-center"><?php echo e($index + 1); ?></td>
                <td><?php echo e($b->nik); ?></td>
                <td><?php echo e(ucwords(strtolower($b->nama))); ?></td>
                <td class="text-center"><?php echo e($b->jenis_kelamin); ?></td>
                <td><?php echo e(ucwords(strtolower($b->nama_orang_tua ?? '-'))); ?></td>
                <td><?php echo e($b->posyandu ?? '-'); ?></td>
                <td><?php echo e($status); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html><?php /**PATH D:\laravel\stunting-ds-sukaharja\resources\views/balita/pdf.blade.php ENDPATH**/ ?>
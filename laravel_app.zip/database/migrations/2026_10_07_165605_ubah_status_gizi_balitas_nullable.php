<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // 1. Ubah kolom status_gizi agar nullable dan default NULL
        Schema::table('balitas', function (Blueprint $table) {
            $table->string('status_gizi')->nullable()->default(null)->change();
        });

        // 2. Bersihkan status_gizi bagi balita yang belum memiliki riwayat penimbangan
        DB::table('balitas')
            ->whereNotIn('id', function ($query) {
                $query->select('balita_id')
                      ->from('penimbangans')
                      ->whereNotNull('balita_id');
            })
            ->update(['status_gizi' => null]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // 1. Kembalikan data NULL menjadi 'Normal' sebelum mengembalikan struktur kolom
        DB::table('balitas')
            ->whereNull('status_gizi')
            ->update(['status_gizi' => 'Normal']);

        // 2. Kembalikan struktur kolom status_gizi seperti semula (not null dengan default 'Normal')
        Schema::table('balitas', function (Blueprint $table) {
            $table->string('status_gizi')->default('Normal')->change();
        });
    }
};